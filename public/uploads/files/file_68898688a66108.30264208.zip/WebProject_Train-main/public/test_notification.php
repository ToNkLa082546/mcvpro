<?php
// เปิดใช้งาน session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
ini_set('display_errors', 1);
error_reporting(E_ALL);

// =======================================================
// === ✅✅✅ เพิ่มส่วนนี้เพื่อโหลด .env ✅✅✅ ===
// =======================================================
require_once realpath(__DIR__ . '/../vendor/autoload.php');
try {
    $dotenv = Dotenv\Dotenv::createImmutable(realpath(__DIR__ . '/../'));
    $dotenv->load();
} catch (\Dotenv\Exception\InvalidPathException $e) {
    die("Could not find .env file. Please ensure it exists in the root directory.");
}
// =======================================================

// --- 1. โหลดไฟล์ที่จำเป็น ---
define('ROOT_PATH', realpath(__DIR__ . '/../') . DIRECTORY_SEPARATOR);
require_once ROOT_PATH . 'core/connect.php'; // ตอนนี้จะทำงานได้แล้ว
require_once ROOT_PATH . 'app/models/Notification.php';

// ... โค้ดที่เหลือเหมือนเดิมทั้งหมด ...

echo "<!DOCTYPE html><html lang='en'><head><title>Notification Test</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'></head>";
echo "<body class='bg-light'><div class='container my-5'><div class='card shadow-sm'><div class='card-body'>";
echo "<h1 class='card-title'>Notification System Test</h1>";

// 🔴🔴🔴 สำคัญ: แก้เลขนี้ให้เป็น user_id จริงๆ ของ Staff (Role 1 หรือ 2) 🔴🔴🔴
$test_staff_id = 23;

echo "<p>Testing for Staff User ID: <strong>{$test_staff_id}</strong></p><hr>";

try {
    $notificationModel = new Notification($pdo);
    echo "<p class='text-success'>✅ Step 1: Notification Model created successfully.</p>";

    echo "<h2>Step 2: Testing Notification Creation...</h2>";
    $test_message = "This is a test notification sent at " . date('H:i:s');
    $test_link = "/quotations/view/999";
    $is_created = $notificationModel->create($test_staff_id, $test_message, $test_link);
    if ($is_created) {
        echo "<p class='text-success'>✅ Notification created successfully in the database.</p>";
    } else {
        echo "<p class='text-danger'>❌ Failed to create notification.</p>";
    }
    echo "<hr>";

    echo "<h2>Step 3: Testing Unread Count...</h2>";
    $unread_count = $notificationModel->countUnreadForUser($test_staff_id);
    echo "<p>Result from <code>countUnreadForUser({$test_staff_id})</code>: </p>";
    echo "<pre class='alert alert-info'>";
    var_dump($unread_count);
    echo "</pre>";
    echo "<hr>";

    echo "<h2>Step 4: Testing Fetching Unread Notifications...</h2>";
    $notifications = $notificationModel->getUnreadForUser($test_staff_id);
    echo "<p>Result from <code>getUnreadForUser({$test_staff_id})</code>: </p>";
    echo "<pre class='alert alert-info'>";
    var_dump($notifications);
    echo "</pre>";

} catch (Exception $e) {
    echo "<div class='alert alert-danger'><h2>An Error Occurred!</h2><p>" . $e->getMessage() . "</p></div>";
}

echo "</div></div></div></body></html>";