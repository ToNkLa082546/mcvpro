document.addEventListener('DOMContentLoaded', function () {

    // --- 1. ประกาศตัวแปรทั้งหมด ---
    const customerSelect = document.getElementById('customer_id');
    const projectSelect = document.getElementById('project_id');
    const addItemBtn = document.getElementById('add-item-btn');
    const itemsContainer = document.getElementById('items-container');
    const quotationForm = document.getElementById('quotation-form');
    const nextStepBtn = document.getElementById('next-step-btn');

    // --- 2. ฟังก์ชันทั้งหมด ---

    /**
     * รันลำดับเลขของรายการและรายการย่อยใหม่ทั้งหมด
     */
    function updateItemNumbers() {
        const rows = itemsContainer.querySelectorAll('tr');
        let mainCounter = 0;
        let subCounter = 0;

        rows.forEach(row => {
            const numberCell = row.querySelector('td:first-child');
            if (!numberCell) return;

            // จัดการไอคอนลากและเลขลำดับ
            if (row.classList.contains('sub-item-row')) {
                subCounter++;
                const numberSpan = row.querySelector('.sub-item-number');
                if (numberSpan) {
                    numberSpan.textContent = `${mainCounter}.${subCounter}`;
                }
                numberCell.innerHTML = `<i class="fas fa-grip-vertical drag-handle" style="cursor: grab; color: #ced4da;"></i>`;
            } else {
                mainCounter++;
                subCounter = 0;
                numberCell.innerHTML = `<i class="fas fa-grip-vertical drag-handle" style="cursor: grab; color: #ced4da;"></i><span class="ms-2">${mainCounter}</span>`;
            }
        });
    }

    /**
     * คำนวณยอดรวมทั้งหมด
     */
    function calculateTotals() {
        let subTotal = 0;
        const subTotalInput = document.getElementById('sub-total');
        const vatAmountInput = document.getElementById('vat-amount');
        const grandTotalInput = document.getElementById('grand-total');
        const VAT_RATE = 0.07;

        itemsContainer.querySelectorAll('tr').forEach(row => {
            const costInput = row.querySelector('.item-cost');
            const marginInput = row.querySelector('.item-margin');
            const quantityInput = row.querySelector('.item-quantity');

            // ข้ามไปถ้าแถวนั้นไม่มี input ราคา
            if (!costInput || !marginInput || !quantityInput) return;

            // คำนวณราคาทุกแถว โดยไม่สนใจ Type
            const cost = parseFloat(costInput.value) || 0;
            const margin = parseFloat(marginInput.value) || 0;
            const quantity = parseInt(quantityInput.value) || 0;
            
            const pricePerUnit = cost * (1 + (margin / 100));
            const itemTotal = pricePerUnit * quantity;

            row.querySelector('.item-price').value = pricePerUnit.toFixed(2);
            row.querySelector('.item-total').value = itemTotal.toFixed(2);
            
            // บวกยอดรวมของทุกแถว
            subTotal += itemTotal;
        });

        const vatAmount = subTotal * VAT_RATE;
        const grandTotal = subTotal + vatAmount;

        if (subTotalInput) subTotalInput.value = subTotal.toFixed(2);
        if (vatAmountInput) vatAmountInput.value = vatAmount.toFixed(2);
        if (grandTotalInput) grandTotalInput.value = grandTotal.toFixed(2);
    }

    /**
     * สร้างแถวสำหรับ "รายการหลัก" และคืนค่าแถวนั้นกลับไป
     */
    function addNewItemRow() {
        const tempId = 'temp_id_' + Date.now();
        const row = document.createElement('tr');
        row.dataset.tempId = tempId;

        row.innerHTML = `
            <td class="item-no text-center" style="vertical-align: middle;"></td>
            <td>
                <input type="text" name="items[item_name][]" class="form-control item-name" required placeholder="Item Name">
                <textarea name="items[description][]" class="form-control item-description mt-1" rows="2" placeholder="Description..." style="display: none;"></textarea>
                <button type="button" class="btn btn-outline-danger btn-sm remove-description-btn" style="display: none;">&times; Remove Description</button>
                <button type="button" class="btn btn-outline-success btn-sm add-description-btn">+ Description</button>
                <button type="button" class="btn btn-outline-success btn-sm add-subitem-btn mt-1" title="Add Sub-item">+ Sub</button>
                <input type="hidden" name="items[temp_id][]" value="${tempId}">
                <input type="hidden" name="items[is_subitem][]" value="0">
                <input type="hidden" name="items[parent_temp_id][]" value="">
            </td>
            <td>
            <select name="items[type][]" class="form-select form-select-sm item-type">
                <option value="show">Show</option>
                <option value="hide">Hide</option>
            </select>
            </td>
            <td><input type="number" name="items[cost][]" class="form-control item-cost" step="0.01" min="0" value="0" required></td>
            <td><input type="number" name="items[margin][]" class="form-control item-margin" step="0.1" min="0" value="20" required></td>
            <td><input type="text" class="form-control-plaintext text-end item-price" value="0.00" readonly></td>
            <td><input type="number" name="items[quantity][]" class="form-control item-quantity" min="1" value="1" required></td>
            <td><input type="text" class="form-control-plaintext text-end item-total" value="0.00" readonly></td>
            <td class="text-center" style="vertical-align: middle;"><button type="button" class="btn btn-danger btn-sm remove-item-btn"><i class="fas fa-trash"></i></button></td>
        `;
        itemsContainer.appendChild(row);
        return row;
    }

    /**
     * สร้างแถวสำหรับ "รายการย่อย" และคืนค่าแถวนั้นกลับไป
     */
    function addNewSubItemRow(parentRow) {
        const row = document.createElement('tr');
        row.classList.add('sub-item-row');
        const parentTempId = parentRow.dataset.tempId;

        row.innerHTML = `
            <td class="item-no text-center" style="vertical-align: middle;"></td>
            <td style="background-color: #f8f9fa;">
                <div class="d-flex align-items-center">
                    <span class="sub-item-number me-2 fw-bold"></span>
                    <input type="text" name="items[item_name][]" class="form-control form-control-sm item-name" required placeholder="Sub-item name">
                </div>
                <div class="ps-4">
                    <textarea name="items[description][]" class="form-control form-control-sm item-description mt-1" rows="1" placeholder="Description..." style="display: none;"></textarea>
                    <button type="button" class="btn btn-outline-danger btn-sm remove-description-btn" style="display: none;">&times; Remove Description</button>
                    <button type="button" class="btn btn-outline-success btn-sm add-description-btn">+ Description</button>
                </div>
                <input type="hidden" name="items[temp_id][]" value="">
                <input type="hidden" name="items[is_subitem][]" value="1">
                <input type="hidden" name="items[parent_temp_id][]" value="${parentTempId}">
            </td>
            <td>
            <select name="items[type][]" class="form-select form-select-sm item-type">
                <option value="show">Show</option>
                <option value="hide">Hide</option>
            </select>
        </td>
            <td><input type="number" name="items[cost][]" class="form-control form-control-sm item-cost" step="0.01" min="0" value="0" required></td>
            <td><input type="number" name="items[margin][]" class="form-control form-control-sm item-margin" step="0.1" min="0" value="0" required></td>
            <td><input type="text" class="form-control-plaintext form-control-sm text-end item-price" value="0.00" readonly></td>
            <td><input type="number" name="items[quantity][]" class="form-control form-control-sm item-quantity" min="1" value="1" required></td>
            <td><input type="text" class="form-control-plaintext form-control-sm text-end item-total" value="0.00" readonly></td>
            <td class="text-center" style="vertical-align: middle;"><button type="button" class="btn btn-danger btn-sm remove-item-btn"><i class="fas fa-trash"></i></button></td>
        `;
        parentRow.insertAdjacentElement('afterend', row);
        return row;
    }

    /**
     * อ่านข้อมูลเดิมจากหน้า Edit มาสร้างฟอร์ม
     */
    function populateFormWithData() {
        const dataElement = document.getElementById('quotation-data');
        
        // --- กรณีเป็นหน้า "แก้ไข" (เจอข้อมูล JSON) ---
        if (dataElement) {
            const data = JSON.parse(dataElement.textContent);
            
            const createRow = (item, parentRow = null) => {
                // เรียกใช้ฟังก์ชัน addNewItemRow() หรือ addNewSubItemRow() ที่คุณมีอยู่แล้ว
                let newRow = parentRow ? addNewSubItemRow(parentRow) : addNewItemRow();
                
                // --- เติมข้อมูลลงในช่องต่างๆ ---
                newRow.querySelector('.item-name').value = item.item_name || '';
                newRow.querySelector('.item-cost').value = item.cost || '0';
                newRow.querySelector('.item-margin').value = item.margin || '0';
                newRow.querySelector('.item-quantity').value = item.quantity || '1';
                
                const typeSelect = newRow.querySelector('.item-type');
                if (typeSelect) {
                    typeSelect.value = item.type || 'show';
                    // ถ้า type เป็น hide ให้เพิ่ม class เพื่อแสดงผลให้จางลง
                    if(typeSelect.value === 'hide'){
                        newRow.classList.add('hidden-in-quote');
                    }
                }
    
                const descTextarea = newRow.querySelector('.item-description');
                if (item.description && descTextarea) {
                    descTextarea.value = item.description;
                    descTextarea.style.display = 'block'; 
                }
                return newRow;
            };

            itemsContainer.innerHTML = ''; 
            
            if (data.items && data.items.length > 0) {
                // วนลูปสร้างรายการหลักและรายการย่อย
                data.items.forEach(mainItem => {
                    const mainRow = createRow(mainItem);
                    if (mainRow && mainItem.children && mainItem.children.length > 0) {
                        mainItem.children.forEach(subItem => {
                            createRow(subItem, mainRow);
                        });
                    }
                });
            } else {
                addNewItemRow();
            }

        } else {
          
            addNewItemRow();
        }

 
        calculateTotals();
        updateItemNumbers();
    }

    // --- 3. Event Listeners และการเริ่มต้นทำงาน ---

    if (addItemBtn) {
        addItemBtn.addEventListener('click', () => {
             const newRow = addNewItemRow();
             updateItemNumbers();
             calculateTotals();
        });
    }

    if (itemsContainer) {
        itemsContainer.addEventListener('click', e => {
            if (e.target.closest('.remove-item-btn')) {
                e.target.closest('tr').remove();
                updateItemNumbers();
                calculateTotals();
                return;
            }
            
            const addSubItemBtn = e.target.closest('.add-subitem-btn');
            if (addSubItemBtn) {
                const parentRow = addSubItemBtn.closest('tr');
                addNewSubItemRow(parentRow);
                updateItemNumbers();
                calculateTotals();
                return;
            }

            const parentCell = e.target.closest('td');
            if (!parentCell) return;

            if (e.target.closest('.add-description-btn')) {
                parentCell.querySelector('.item-description').style.display = 'block';
                parentCell.querySelector('.remove-description-btn').style.display = 'inline-block';
                e.target.closest('.add-description-btn').style.display = 'none';
            }

            if (e.target.closest('.remove-description-btn')) {
                const descriptionTextarea = parentCell.querySelector('.item-description');
                descriptionTextarea.value = '';
                descriptionTextarea.style.display = 'none';
                parentCell.querySelector('.add-description-btn').style.display = 'inline-block';
                e.target.closest('.remove-description-btn').style.display = 'none';
            }
        });

        itemsContainer.addEventListener('change', e => {
            if (e.target.matches('.item-type')) {
                const row = e.target.closest('tr');
                if (e.target.value === 'hide') {
                    row.classList.add('hidden-in-quote');
                } else {
                    row.classList.remove('hidden-in-quote');
                } 
                calculateTotals();
            }
        });

        itemsContainer.addEventListener('input', e => {
            if (e.target.matches('.item-cost, .item-margin, .item-quantity')) {
                calculateTotals();
            }
        });
        
        // เปิดใช้งาน Drag and Drop
        new Sortable(itemsContainer, {
            animation: 150,
            handle: '.drag-handle',
            onEnd: function () {
                updateItemNumbers();
            }
        });
    }
     // ✅ B. ถ้าเป็นหน้าเลือกโปรเจกต์ (มีปุ่ม Next)
    // ✅ B. ถ้าเป็นหน้าเลือกโปรเจกต์ (มีปุ่ม Next)
    if (nextStepBtn) {
        // 1. ประกาศตัวแปรให้ครบ รวมถึง container ที่ครอบ project select
        const customerSelect = document.getElementById('customer_id');
        const projectContainer = document.getElementById('project-container'); // <-- เพิ่มบรรทัดนี้
        const projectSelect = document.getElementById('project_id');

        if (!customerSelect || !projectContainer || !projectSelect) {
            console.error("Customer or Project dropdown not found!");
            return;
        }

        const allProjectOptions = Array.from(projectSelect.options);

        function filterProjectsAndToggleVisibility() {
            const customerId = customerSelect.value;

            // 2. เพิ่ม Logic การซ่อน/แสดง Container
            if (customerId) {
                // ถ้าเลือกลูกค้าแล้ว ให้แสดง container
                projectContainer.style.display = 'block';
            } else {
                // ถ้ายังไม่เลือก ให้ซ่อน container กลับไป
                projectContainer.style.display = 'none';
                projectSelect.value = ""; // Reset ค่าที่เลือกไว้
                return; // หยุดทำงาน ไม่ต้องกรอง
            }

            // 3. กรองรายการ Project (เหมือนเดิม)
            projectSelect.innerHTML = '';
            const defaultOption = document.createElement('option');
            defaultOption.value = "";
            defaultOption.textContent = '-- Select a project --';
            defaultOption.selected = true;
            projectSelect.appendChild(defaultOption);

            allProjectOptions.forEach(option => {
                if (option.dataset.customerId === customerId) {
                    projectSelect.appendChild(option.cloneNode(true));
                }
            });
            projectSelect.disabled = false;
        }

        // 4. ผูก Event Listener
        customerSelect.addEventListener('change', filterProjectsAndToggleVisibility);

        nextStepBtn.addEventListener('click', function () {
            const projectId = projectSelect.value;
            if (projectId) {
                // ควรจะเข้ารหัส ID ก่อนส่งไปใน URL เพื่อให้สอดคล้องกับ Controller ของคุณ
                window.location.href = '/mcvpro/public/quotations/create/' + projectId;
            } else {
                alert('Please select a customer and a project first.');
            }
        });
    }
    if (quotationForm) {
        quotationForm.addEventListener('submit', function() {
            // ค้นหา dropdown ลูกค้าในหน้านั้นๆ
            const customerSelectOnSubmit = document.getElementById('customer_id');

            // ตรวจสอบก่อนว่ามี dropdown นี้อยู่จริงหรือไม่
            if (customerSelectOnSubmit) {
                // ถ้ามี (เฉพาะในหน้า Create) ให้ปลดล็อกก่อน submit
                customerSelectOnSubmit.disabled = false;
            }
            
            // ถ้าไม่เจอ (ในหน้า Edit) โค้ดส่วนนี้จะไม่ทำงาน และฟอร์มจะ submit ได้ปกติ
        });
    }
    // --- 4. เริ่มต้นการทำงาน ---
    populateFormWithData();
});
    
    
