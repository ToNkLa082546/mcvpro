document.addEventListener('DOMContentLoaded', function() {
    const notificationLinks = document.querySelectorAll('a.notification-item');

    notificationLinks.forEach(link => {
        link.addEventListener('click', function(event) {
             console.log('Notification link clicked! ID:', this.dataset.notificationId);
            event.preventDefault();
            const notificationItem = this; // เก็บ <a> ที่ถูกคลิก
            const notificationId = notificationItem.dataset.notificationId;
            const destinationUrl = notificationItem.href;

            // ส่ง Request ไปเบื้องหลัง
            fetch('/mcvpro/public/notifications/read/' + notificationId, {
                method: 'POST',
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(response => {
                if (response.ok) {
                    // --- อัปเดตหน้าเว็บทันที ---
                    const badge = document.getElementById('notification-badge');
                    if (badge) {
                        let count = parseInt(badge.textContent) - 1;
                        if (count > 0) {
                            badge.textContent = count;
                        } else {
                            badge.remove(); // ถ้าเหลือ 0 ให้ลบป้ายแดงทิ้ง
                        }
                    }
                    // ลบรายการที่คลิกออกจาก dropdown
                    notificationItem.closest('li').remove();
                }
            })
            .catch(error => console.error('Error:', error))
            .finally(() => {
                // ไปยังหน้าปลายทาง
                window.location.href = destinationUrl;
            });
        });
    });
});

document.getElementById('clear-notifications')?.addEventListener('click', function () {
    if (confirm('คุณต้องการล้างการแจ้งเตือนทั้งหมดหรือไม่?')) {
      // ส่ง request ไปล้างการแจ้งเตือน (AJAX หรือ link)
      fetch('/mcvpro/public/notifications/clear', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      }).then(response => {
        if (response.ok) {
          // อัปเดต UI
          document.getElementById('notification-dropdown').innerHTML = `
            <li class="dropdown-item-text text-muted text-center py-2">ไม่มีการแจ้งเตือนใหม่</li>
          `;
          const badge = document.getElementById('notification-badge');
          if (badge) badge.remove();
        }
      });
    }
  });