


const ctxStatus = document.getElementById('StatusChart').getContext('2d');

new Chart(ctxStatus, {
  type: 'bar',
  data: {
    labels: ['Overview'], // หมายถึงกลุ่มเดียว แต่มีหลายชุดข้อมูล
    datasets: [
      {
        label: 'Users',
        data: [total_users],
        backgroundColor: '#198754'
      },
      {
        label: 'Customers',
        data: [total_customers],
        backgroundColor: '#0dcaf0'
      },
      {
        label: 'Projects',
        data: [total_projects],
        backgroundColor: '#ffc107'
      },
      {
        label: 'Quotations',
        data: [total_quotations],
        backgroundColor: '#fd7e14'
      }
    ]
  },
  options: {
    responsive: true,
    plugins: {
      legend: {
        display: false
      }
    }
  }
});

