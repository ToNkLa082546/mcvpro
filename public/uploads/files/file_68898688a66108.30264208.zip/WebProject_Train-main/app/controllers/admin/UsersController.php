<?php


class UsersController
{
    private $userModel;
    private $pdo; 

    public function __construct(PDO $pdo)
    {

        $this->pdo = $pdo;

        $this->userModel = new User($this->pdo);
    }

    public function index()
    {

        $currentUserId = $_SESSION['user_id'] ?? null;

        if (empty($_SESSION['user_id']) || (int)$_SESSION['user_role'] !== 1) {
            header("Location: /mcvpro/public/login");
            exit;
        }

        $users = $this->userModel->getAllUsers($currentUserId);

        include ROOT_PATH . 'app/views/layout/sidebar.php';
        include ROOT_PATH . 'app/views/users/index.php';
    }
}