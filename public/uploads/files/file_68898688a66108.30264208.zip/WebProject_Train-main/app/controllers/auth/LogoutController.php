<?php
class LogoutController {
    public function index() {

        $logger = LoggerService::getLogger('logout');

    // ✅ บันทึก Log ก่อนที่จะทำลาย Session
    // เราใช้ ?? 'N/A' เผื่อกรณีที่ session ถูกทำลายไปก่อนแล้ว
    $logger->info('User logged out', ['user_id' => $_SESSION['user_id'] ?? 'N/A']);

        session_start();
        session_unset(); // เคลียร์ตัวแปรทั้งหมด
        session_destroy(); // ลบ session

        // กลับไปหน้า login หรือ home
        header('Location: /mcvpro/public');
        exit();
    }
}
