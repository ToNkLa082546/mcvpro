<?php
use Hashids\Hashids;

// สร้าง instance ของ Hashids แค่ครั้งเดียว
$hashids = new Hashids('your-secret-salt-key-123', 10);

/**
 * ฟังก์ชันสำหรับเข้ารหัส ID
 */
function encodeId($id) {
    global $hashids;
    return $hashids->encode($id);
}

/**
 * ฟังก์ชันสำหรับถอดรหัส ID
 */
function decodeId($hashedId) {
    global $hashids;
    $decoded = $hashids->decode($hashedId);
    return !empty($decoded) ? $decoded[0] : null;
}
