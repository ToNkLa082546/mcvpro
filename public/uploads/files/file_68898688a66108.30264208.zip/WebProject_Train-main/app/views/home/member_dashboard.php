<?php
// ดึงข้อมูลจาก Controller มาใส่ในตัวแปรที่ใช้ง่าย
$stats = $data['stats'];
$goal = $data['sales_goal'];

$totalQuotations = $stats['total_quotations'] ?? 0;
$draftQuotations = $stats['draft_quotations'] ?? 0;
$approvedQuotations = $stats['approved_quotations'] ?? 0;
$rejectedQuotations = $stats['rejected_quotations'] ?? 0;
$canceledQuotations = $stats['canceled_quotations'] ?? 0;
$monthlySum = $stats['monthly_approved_sum'] ?? 0;

$progressPercentage = ($goal > 0) ? ($monthlySum / $goal) * 100 : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>My Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="/mcvpro/public/css/dashboard/member.css">
</head>
<body style="background-color: #FFF5EE;">

<div class="container my-5">
  <h2 class="mb-5 text-center fw-bold"><i class="fas fa-user-chart text-info me-2"></i>My Dashboard</h2>

  <!-- Summary Cards -->
  <div class="d-flex flex-wrap justify-content-center gap-3 mb-4">

    <?php
    $cards = [
      ['title' => 'Total', 'value' => $totalQuotations, 'color' => 'primary', 'icon' => 'fa-layer-group'],
      ['title' => 'Draft', 'value' => $draftQuotations, 'color' => 'secondary', 'icon' => 'fa-pen'],
      ['title' => 'Approved', 'value' => $approvedQuotations, 'color' => 'success', 'icon' => 'fa-circle-check'],
      ['title' => 'Rejected', 'value' => $rejectedQuotations, 'color' => 'danger', 'icon' => 'fa-circle-xmark'],
      ['title' => 'Canceled', 'value' => $canceledQuotations, 'color' => 'dark', 'icon' => 'fa-ban'],
    ];

    foreach ($cards as $card): ?>
      <div class="col-md-3">
        <div class="card h-100 shadow-sm text-center border-0 bg-light rounded-4">
          <div class="card-body">
            <h6 class="card-title text-<?= $card['color'] ?> fw-bold text-uppercase mb-2">
              <i class="fas <?= $card['icon'] ?> me-1"></i> <?= $card['title'] ?>
            </h6>
            <p class="card-text display-6 fw-bold"><?= $card['value'] ?></p>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- Monthly Summary -->
  <div class="row justify-content-center mt-5">
    <div class="col-md-6">
      <div class="card shadow-sm border-0 rounded-4">
        <div class="card-body">
          <h5 class="card-title text-muted mb-3">
            <i class="fas fa-coins me-2 text-success"></i>This Month's Approved Total
          </h5>
          <p class="h3 text-success fw-bold">฿ <?= number_format($monthlySum, 2) ?></p>

          <div class="mt-4">
            <small class="text-muted">Goal: ฿ <?= number_format($goal, 2) ?></small>
            <div class="progress mt-1 rounded-pill" style="height: 20px;">
              <div class="progress-bar bg-success fw-semibold" role="progressbar" 
                   style="width: <?= min($progressPercentage, 100) ?>%;" 
                   aria-valuenow="<?= $progressPercentage ?>" aria-valuemin="0" aria-valuemax="100">
                <?= round($progressPercentage) ?>%
              </div>
            </div>

            <?php if ($monthlySum >= $goal): ?>
              <div class="mt-3 text-success fw-bold">
                <i class="fas fa-trophy me-2"></i>Congratulations! Goal achieved!
              </div>
            <?php else: ?>
              <div class="mt-3 text-warning fw-bold">
                <i class="fas fa-running me-2"></i>Keep going! You're almost there.
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>
