<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="/mcvpro/public/css/dashboard/admin.css">
</head>
<body style="background-color: #FFF5EE;">

<div class="container py-4">
  <div class="dashboard-title border-bottom pb-2 mb-4">
    <h1 class="h2">Admin Dashboard</h1>
  </div>

  <!-- Stats Section -->
  <div class="row g-4">
    <!-- Row 1 -->
    <div class="col-md-6">
      <div class="card stat-card bg-primary shadow "style="cursor: pointer;" onclick="location.href='/mcvpro/public/users/index'">
        <div class="card-body">
          <div class="stat-text">
            <h5><i class="fas fa-users me-2"></i> Total Users</h5>
            <div class="stat-number" id="total-users"><?= $data['stats']['total_users'] ?? '-' ?></div>
          </div>
          <div class="stat-icon"><i class="fas fa-users"></i></div>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card stat-card bg-success shadow "style="cursor: pointer;" onclick="location.href='/mcvpro/public/customers/index'">
        <div class="card-body">
          <div class="stat-text">
            <h5><i class="fas fa-building me-2"></i> Total Customers</h5>
            <div class="stat-number" id="total-customers"><?= $data['stats']['total_customers'] ?? '-' ?></div>
          </div>
          <div class="stat-icon"><i class="fas fa-building"></i></div>
        </div>
      </div>
    </div>

    <!-- Row 2 -->
    <div class="col-md-6">
      <div class="card stat-card bg-info shadow "style="cursor: pointer;" onclick="location.href='/mcvpro/public/projects'">
        <div class="card-body">
          <div class="stat-text">
            <h5><i class="fas fa-folder-open me-2"></i> Total Projects</h5>
            <div class="stat-number" id="total-projects"><?= $data['stats']['total_projects'] ?? '-' ?></div>
          </div>
          <div class="stat-icon"><i class="fas fa-folder-open"></i></div>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card stat-card bg-warning shadow "style="cursor: pointer;" onclick="location.href='/mcvpro/public/quotations'">
        <div class="card-body">
          <div class="stat-text">
            <h5><i class="fas fa-folder me-2"></i> Total Quotations</h5>
            <div class="stat-number" id="total-quotations"><?= $data['stats']['total_quotations'] ?? '-' ?></div>
          </div>
          <div class="stat-icon"><i class="fas fa-folder"></i></div>
        </div>
      </div>
    </div>
  </div>
<script src="/mcvpro/public/js/admin-dashboard.js"></script>
</body>
</html>
