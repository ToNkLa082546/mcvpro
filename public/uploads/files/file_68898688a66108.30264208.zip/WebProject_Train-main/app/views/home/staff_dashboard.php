<?php
$totalQuotations = $data['total_quotations'] ?? 0;
$totalApprovedValue = $data['total_approved_value'] ?? 0;
$memberSummary = $data['member_summary'] ?? [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Staff Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="/mcvpro/public/css/dashboard/staff.css">
</head>
<body style="background-color: #FFF5EE;">

<div class="container py-5">
  <h2 class="text-center dashboard-title mb-5">👩‍💼 Staff Dashboard</h2>

  <div class="row g-4 justify-content-center">
    <!-- Total Quotations -->
    <div class="col-md-6">
      <div class="card card-highlight shadow-sm">
        <div class="card-body text-center">
          <i class="fas fa-file-invoice fa-2x text-primary mb-3"></i>
          <h5 class="text-muted">Total Quotations</h5>
          <p class="display-4 fw-bold text-primary"><?= $totalQuotations ?></p>
        </div>
      </div>
    </div>

    <!-- Approved Amount -->
    <div class="col-md-6">
      <div class="card card-highlight shadow-sm">
        <div class="card-body text-center">
          <i class="fas fa-handshake fa-2x text-success mb-3"></i>
          <h5 class="text-muted">Approved Amount</h5>
          <p class="display-4 fw-bold text-success">฿ <?= number_format($totalApprovedValue, 2) ?></p>
        </div>
      </div>
    </div>
  </div>


 <!-- Member Performance Table -->
<div class="card shadow-sm mt-5">
  <div class="card-header bg-white border-bottom">
    <h5 class="mb-0 fw-bold">
      <i class="fas fa-chart-line me-2 text-info"></i> This Month's Member Performance
    </h5>
  </div>
  <div class="card-body">
    <div class="table-responsive mt-3">
      <table class="table table-hover align-middle">
        <thead class="table-light text-center align-middle">
          <tr>
            <th class="text-start fw-bold">Member Name</th>
            <th class="fw-bold">Total</th>
            <th class="fw-bold text-secondary">Draft</th>
            <th class="fw-bold text-success">Approved</th>
            <th class="fw-bold text-danger">Rejected</th>
            <th class="fw-bold text-dark">Canceled</th>
            <th class="text-end fw-bold">Total Value</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($memberSummary)): ?>
            <tr>
              <td colspan="7" class="text-center text-muted py-4">No data for this month yet.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($memberSummary as $summary): ?>
              <tr class="text-center border-bottom">
                <td class="text-start fw-semibold"><?= htmlspecialchars($summary['member_name']) ?></td>
                <td><?= $summary['monthly_quotation_count'] ?></td>
                <td class="text-secondary fw-bold"><?= $summary['monthly_draft_count'] ?></td>
                <td class="text-success fw-bold"><?= $summary['monthly_approved_count'] ?></td>
                <td class="text-danger fw-bold"><?= $summary['monthly_rejected_count'] ?></td>
                <td class="text-dark fw-bold"><?= $summary['monthly_canceled_count'] ?></td>
                <td class="text-end fw-semibold text-primary">฿ <?= number_format($summary['monthly_quotation_sum'], 2) ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>


</div>

</body>
</html>
