<?php
// core/Controller.php

class Controller
{
    protected $pdo;

    public function __construct($pdo)
    {
        $this->pdo = $pdo;
    }

    
    protected function auth()
    {
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['error'] = 'กรุณาเข้าสู่ระบบก่อนใช้งาน';
            header('Location: /mcvpro/public/auth/login');
            exit();
        }
    }

 protected function hasRole(array $allowedRoles)
{
    if (!isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], $allowedRoles)) {
        http_response_code(403);
        die("<h1>403 Forbidden</h1><p>You do not have permission to access this page.</p>");
    }
}

protected function isAllowed(array $allowedRoles): bool
    {
        if (!isset($_SESSION['user_role'])) {
            return false;
        }
        
        // in_array(..., ..., true) จะเปรียบเทียบชนิดข้อมูล (type) ด้วย
        // ทำให้แน่ใจว่า int(1) จะไม่สับสนกับ string("1")
        return in_array($_SESSION['user_role'], $allowedRoles, true);
    }


}